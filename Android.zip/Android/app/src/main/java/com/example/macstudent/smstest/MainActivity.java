package com.example.macstudent.smstest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    //OKHttp varibale
    OkHttpClient client = new OkHttpClient();

    //user interface varibale
    TextView textViewMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize the outlet
        textViewMain = (TextView) findViewById(R.id.textViewMain);
    }

    //action(click handler) for button
    public void buttonPressed(View v) {

        //opriotn 1 for output
//        System.out.println("Click");

        //option2 Android Logging System
        Log.d("Android App","Person Clicked The Message");

        //1. Tell system what uRL you want to go
        String URL = "https://api.coindesk.com/v1/bpi/historical/close.json?currency=BRL&start=2018-01-01&end=2018-01-10";
        Request request = new Request.Builder().url(URL).build();

        //2. Send the request to internet ans wait for response
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //what should happen if request fails?
                e.printStackTrace(); //print the error
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //if the request successfull
                Log.d("ANDROID","Request Successfull!!!");

                if (response.isSuccessful()) {
                    //what happens if request is successfull?
                    final String reply = response.body().string();

                    try {
                        //1. make a json object
                        JSONObject json = new JSONObject(reply);

                        JSONObject bpi = json.getJSONObject("bpi");
                        String disclaimer = json.getString("disclaimer");
                        Log.d("ANDROID",disclaimer);
                        Log.d("ANDROID",bpi.toString());

                        //iterarte thrgh the dictionary
                        int totalItems = bpi.length();
                        double sum =0;
                        int i = 0;
                        Iterator<String> iterator = bpi.keys();
                        while (iterator.hasNext()) {
                            String key = iterator.next();

                            //get the current price
                            double price = bpi.getDouble(key);

                            //add up all the prices
                            sum = sum + price;
                        }

                        //calculate average
                        double average = sum / totalItems;
                        Log.d("ANDROID","AVERAGE");
                        Log.d("ANDROID",Double.toString(average));



                        while (iterator.hasNext()) {
                            String key = iterator.next();
//
                            double price = bpi.getDouble(key);
//                            JSONObject item = iterator.next();
//                            String key = item.keys().next();

//                            Log.d("ANDROID","PRINTING OUT THE VALUES");
//                            Log.d("ANDOID",item.toString());
//                            Log.d("ANDROID",)

                            Log.d("ANDOID","KEY");
                            Log.d("ANDROID",key);

                            Log.d("ANDROID","PRINTING OUT THE ITEMS");
                            Log.d("ANDROID",Double.toString(price));
                        }

//                        //2. parse the stuff inside the object
//                        int userId = json.getInt("userId");
//                        String title = json.getString("title");
//                        boolean done = json.getBoolean("completed");
//
//                        //3. do somethoing with the variables
//                        Log.d("UserID",Integer.toString(userId));
//                        Log.d("Title",title);
//                        Log.d("Complted",Boolean.toString(done));
//
//                        //4. lets do some stupid logic
//                        if(done == false) {
//                            Log.d("JSONPARSER","The System is Down");
//                        }
//
//                        if(userId == 1) {
//                            Log.d("JSON",title);
//                        }

                    } catch(Exception e) {
                        Log.d("ANDROID","Error while parsing JSON");
                        e.printStackTrace();
                    }



//                    //output json output to terminal
//                    Log.d("ANDOID",reply);
//
//                    //3. Do something with the response
//                    MainActivity.this.runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            //UI Sections
//                            textViewMain.setText(reply);
//                        }
//                    });
                }
            }
        });



    }
}
